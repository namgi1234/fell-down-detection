# fell down detection > 2022-11-12 11:42am
https://universe.roboflow.com/object-detection/fell-down-detection

Provided by a Roboflow user
License: CC BY 4.0

